.. currentmodule:: kombu.transport.pyredis

.. automodule:: kombu.transport.pyredis

    .. contents::
        :local:

    Transport
    ---------

    .. autoclass:: Transport
        :members:
        :undoc-members:

    Channel
    -------

    .. autoclass:: Channel
        :members:
        :undoc-members:
