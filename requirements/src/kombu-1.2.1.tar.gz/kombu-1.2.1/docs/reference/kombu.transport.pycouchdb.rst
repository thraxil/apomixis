.. currentmodule:: kombu.transport.pycouchdb

.. automodule:: kombu.transport.pycouchdb

    .. contents::
        :local:

    Transport
    ---------

    .. autoclass:: Transport
        :members:
        :undoc-members:

    Channel
    -------

    .. autoclass:: Channel
        :members:
        :undoc-members:

    Functions
    ---------

    .. autofunction:: create_message_view
