=====================================================
 celery.schedules
=====================================================

.. contents::
    :local:
.. currentmodule:: celery.schedules

.. automodule:: celery.schedules
    :members:
    :undoc-members:
