===============================================
 celery.backends.tyrant
===============================================

.. contents::
    :local:
.. currentmodule:: celery.backends.tyrant

.. automodule:: celery.backends.tyrant
    :members:
    :undoc-members:
