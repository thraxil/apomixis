=============================================================
 celery.concurrency.evlet† (*experimental*)
=============================================================

.. contents::
    :local:
.. currentmodule:: celery.concurrency.evlet

.. automodule:: celery.concurrency.evlet
    :members:
    :undoc-members:
