def foo():
    pass

def bar():
    pass
